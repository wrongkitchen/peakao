<?php
class Magestore_Auction_Block_Widget implements Mage_Widget_Block_Interface
{
    protected function _toHtml()
    {
        $this->setTemplate('auction/widget.phtml');

    }
    
   

}