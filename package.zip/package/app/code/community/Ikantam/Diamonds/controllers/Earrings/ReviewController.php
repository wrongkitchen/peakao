<?php

class Ikantam_Diamonds_Earrings_ReviewController extends Mage_Core_Controller_Front_Action {

    public function designAction() {

        
          	$this->loadLayout()->renderLayout();
    }


}