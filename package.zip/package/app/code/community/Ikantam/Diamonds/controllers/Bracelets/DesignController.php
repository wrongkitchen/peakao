<?php
class Ikantam_Diamonds_Bracelets_DesignController extends Mage_Core_Controller_Front_Action
{
	public function indexAction()
	{
	  echo "index";

	}

 


}