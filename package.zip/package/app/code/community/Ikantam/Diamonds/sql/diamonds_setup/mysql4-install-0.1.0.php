<?php
/* @var $this Ikantam_Diamonds_Model_Entity_Setup */
$installer = $this;

$installer->startSetup();

$installer->addAttributeSets();



$installer->run("");
$installer->endSetup(); 