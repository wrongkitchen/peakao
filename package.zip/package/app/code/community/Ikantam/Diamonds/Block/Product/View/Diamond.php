<?php


class Ikantam_Diamonds_Block_Product_View_Diamond extends Mage_Catalog_Block_Product_View
{
	
	
}