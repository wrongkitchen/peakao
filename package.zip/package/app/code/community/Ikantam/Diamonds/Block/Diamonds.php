<?php

class Ikantam_Diamonds_Block_Diamonds extends Mage_Core_Block_Template {

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

}