<?php


class Ikantam_Diamonds_Block_Product_View_Setting extends Mage_Catalog_Block_Product_View
{
}