<?php

class Ikantam_Diamonds_Block_Media extends Mage_Core_Block_Template {

    public function _construct() {
      $this->settemplate("diamonds/product/media.phtml");
    }
	

}