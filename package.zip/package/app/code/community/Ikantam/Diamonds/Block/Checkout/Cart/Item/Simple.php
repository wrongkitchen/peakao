<?php

class Ikantam_Diamonds_Block_Checkout_Cart_Item_Simple extends Mage_Checkout_Block_Cart_Item_Renderer
{
	
	
	
}
