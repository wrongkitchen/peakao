<?php

class Ikantam_Diamonds_Block_Quickview extends Mage_Core_Block_Template {

    protected function _construct()
    {
        parent::_construct();
    }


}