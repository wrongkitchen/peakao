<?php
/**
 * Magegiant
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the magegiant.com license that is
 * available through the world-wide-web at this URL:
 * https://magegiant.com/license-agreement/
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    Magegiant
 * @package     Magegiant
 * @copyright   Copyright (c) 2015 Magegiant (https://magegiant.com/)
 * @license     http://magegiant.com/license-agreement/
 */


class Magegiant_SocialLogin_Model_Config_Abstract {

	public function toOptionArray()
	{
		return array();
	}
}