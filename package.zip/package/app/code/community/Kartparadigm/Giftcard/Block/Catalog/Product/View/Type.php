<?php

class Kartparadigm_Giftcard_Block_Catalog_Product_View_Type extends Mage_Catalog_Block_Product_View_Abstract
{

}
