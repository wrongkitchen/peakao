<?php

class Kartparadigm_Giftcard_Block_Payment_Info extends Mage_Payment_Block_Info
{
    
}
