<?php
class Kartparadigm_Giftcard_Model_Giftcardtemplate extends Mage_Core_Model_Abstract

{
    public function __construct()

    {
        $this->_init('kartparadigm_giftcard/giftcardtemplate');
        parent::_construct();
    }
}

