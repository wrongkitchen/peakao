<?php
class Kartparadigm_Giftcard_Model_Giftcardtrans extends
Mage_Core_Model_Abstract
{
public function __construct()
{
$this->_init('kartparadigm_giftcard/giftcardtrans');
parent::_construct();
}
}
